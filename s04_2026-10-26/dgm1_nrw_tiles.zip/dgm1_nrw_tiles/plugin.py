"""The plugin class: menu, toolbar buttons and the glue between QGIS and core.py.

QGIS calls classFactory(iface) in __init__.py, then initGui() when the plugin is switched on
and unload() when it is switched off. Everything the plugin adds to QGIS in initGui() must be
removed again in unload().
"""
from datetime import datetime
from pathlib import Path

from qgis.core import (Qgis, QgsApplication, QgsCategorizedSymbolRenderer, QgsFillSymbol, QgsMessageLog,
                       QgsPalLayerSettings, QgsProject, QgsRasterLayer, QgsRendererCategory, QgsSettings,
                       QgsTask, QgsTextFormat, QgsVectorLayer, QgsVectorLayerSimpleLabeling)
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QFileDialog

from . import core

MENU = "&DGM1 NRW Tile Downloader"
LAYER_NAME = "DGM1 tiles NRW"
SETTINGS_KEY = "dgm1_nrw_tiles/data_dir"
MAX_TILES = 50
MAX_AGE_HOURS = 24


def log(text, level=Qgis.Info):
    """Messages go to View -> Panels -> Log Messages, tab 'DGM1 NRW' (safe from a background task)."""
    QgsMessageLog.logMessage(text, "DGM1 NRW", level)


class Dgm1TilesPlugin:
    def __init__(self, iface):
        self.iface = iface              # the QGIS interface: main window, map canvas, message bar, ...
        self.actions = []
        self.task = None                # keep a reference, otherwise Python deletes the running task

    # ---- switched on / off ------------------------------------------------------------------
    def initGui(self):
        here = Path(__file__).parent
        self._add_action(QIcon(str(here / "icon_index.png")), "Load DGM1 tile index", self.load_index, toolbar=True)
        self._add_action(QIcon(str(here / "icon.png")), "Download selected tiles",     # icon.png = plugin icon
                         self.download_selected, toolbar=True)
        self._add_action(QgsApplication.getThemeIcon("/mActionRefresh.svg"), "Check server for a new file list",
                         lambda: self.load_index(force=True))
        self._add_action(QgsApplication.getThemeIcon("/mActionFileOpen.svg"), "Choose data folder...",
                         self.choose_data_dir)

    def _add_action(self, icon, text, slot, toolbar=False):
        action = QAction(icon, text, self.iface.mainWindow())
        action.triggered.connect(slot)
        self.iface.addPluginToMenu(MENU, action)
        if toolbar:
            self.iface.addToolBarIcon(action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(MENU, action)
            self.iface.removeToolBarIcon(action)
        self.actions = []

    # ---- data folder ----------------------------------------------------------------------------
    def data_dir(self, ask=True):
        saved = QgsSettings().value(SETTINGS_KEY, "")
        if saved and Path(saved).is_dir():
            return Path(saved)
        home = QgsProject.instance().homePath()          # <course folder>/data above the project?
        if home:
            for folder in (Path(home), *Path(home).parents[:3]):
                if (folder / "data").is_dir():
                    QgsSettings().setValue(SETTINGS_KEY, str(folder / "data"))
                    return folder / "data"
        return self.choose_data_dir() if ask else None

    def choose_data_dir(self):
        start = QgsSettings().value(SETTINGS_KEY, str(Path.home()))
        chosen = QFileDialog.getExistingDirectory(self.iface.mainWindow(), "Data folder for DGM1 tiles "
                                                  "(the data/ folder of your course folder)", start)
        if not chosen:
            return None
        QgsSettings().setValue(SETTINGS_KEY, chosen)
        self.iface.messageBar().pushMessage("DGM1 NRW", f"data folder: {chosen}", Qgis.Info, 5)
        return Path(chosen)

    # ---- tile index -----------------------------------------------------------------------------
    def _find_layer(self, gpkg):
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and layer.source().split("|")[0] == str(gpkg):
                return layer
        return None

    def refresh(self, root, force=False):
        """Check the file list, rebuild the index if needed; {key: row} of the current list."""
        p = core.paths(root)
        xml_bytes, info, _ = core.fetch_listing(root, force, MAX_AGE_HOURS, log=log)
        rows = core.parse_listing(xml_bytes)
        if not core.index_is_current(p["gpkg"], rows, info):
            layer = self._find_layer(p["gpkg"])
            if layer is not None:
                QgsProject.instance().removeMapLayer(layer.id())
            core.build_index(rows, info, p["gpkg"], log=log)
        return {r["key"]: r for r in rows}

    def load_index(self, force=False):
        root = self.data_dir()
        if root is None:
            return None
        try:
            self.refresh(root, force)
        except Exception as e:                            # show it, do not crash QGIS
            self.iface.messageBar().pushMessage("DGM1 NRW", f"tile index failed: {e}", Qgis.Critical, 10)
            return None
        gpkg = core.paths(root)["gpkg"]
        layer = self._find_layer(gpkg)
        if layer is None:
            layer = QgsVectorLayer(f"{gpkg}|layername=dgm1_tiles", LAYER_NAME, "ogr")
            self._style(layer)
            QgsProject.instance().addMapLayer(layer)
        self.iface.setActiveLayer(layer)
        meta = core.index_info(gpkg)
        self.iface.messageBar().pushMessage(
            "DGM1 NRW", f"{meta.get('tiles')} tiles, file list of {meta.get('last_modified')}. "
                    f"Select tiles, then 'Download selected tiles'.", Qgis.Info, 8)
        return layer

    def _style(self, layer):
        years = sorted({int(v) for v in layer.uniqueValues(layer.fields().indexOf("year"))})
        colours = ["#440154", "#3b528b", "#21918c", "#5ec962", "#fde725", "#f89540", "#cc4778"]
        cats = [QgsRendererCategory(y, QgsFillSymbol.createSimple(
                    {"color": colours[i % len(colours)] + "40", "outline_color": "#555555", "outline_width": "0.1"}), str(y))
                for i, y in enumerate(years)]
        layer.setRenderer(QgsCategorizedSymbolRenderer("year", cats))
        pal = QgsPalLayerSettings()
        pal.fieldName = "key"
        fmt = QgsTextFormat()
        fmt.setSize(8)
        pal.setFormat(fmt)
        pal.scaleVisibility, pal.maximumScale, pal.minimumScale = True, 1, 60000
        layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        layer.setLabelsEnabled(True)

    # ---- download in the background ------------------------------------------------------------
    def download_selected(self):
        root = self.data_dir()
        if root is None:
            return
        layer = self._find_layer(core.paths(root)["gpkg"]) or self.load_index()
        if layer is None:
            return
        keys = sorted({f["key"] for f in layer.selectedFeatures()})
        if not 0 < len(keys) <= MAX_TILES:
            self.iface.messageBar().pushMessage(
                "DGM1 NRW", f"select 1 to {MAX_TILES} tiles on '{LAYER_NAME}' ({len(keys)} selected)", Qgis.Warning, 6)
            return
        if self.task is not None:
            self.iface.messageBar().pushMessage("DGM1 NRW", "a download is still running", Qgis.Warning, 5)
            return
        current = self.refresh(root)                       # names may have changed since the index was loaded
        rows = [current[k] for k in keys if k in current]
        folder = core.paths(root)["original"]
        vrt = folder / f"dgm1_selection_{datetime.now():%Y%m%d_%H%M%S}.vrt"
        total = sum(r["size_bytes"] for r in rows) / 1e6
        # QgsTask runs `_download` in a worker thread; QGIS shows its progress in the status bar
        # (with a cancel button) and calls `_finished` in the main thread when it is done.
        self.task = QgsTask.fromFunction(f"DGM1: {len(rows)} tiles ({total:.0f} MB)", _download, rows, folder, vrt,
                                         on_finished=self._finished)
        QgsApplication.taskManager().addTask(self.task)

    def _finished(self, exception, result=None):
        self.task = None
        if exception is not None:
            if isinstance(exception, core.Canceled):
                self.iface.messageBar().pushMessage("DGM1 NRW", f"download canceled at {exception}; finished tiles "
                                                    "are kept and skipped next time", Qgis.Warning, 8)
            else:
                self.iface.messageBar().pushMessage("DGM1 NRW", f"download failed: {exception}", Qgis.Critical, 10)
            return
        if result is None:                                # canceled before the first tile
            return
        vrt, n_new, n_old = result
        QgsProject.instance().addMapLayer(QgsRasterLayer(str(vrt), vrt.stem))   # map changes: main thread only
        self.iface.messageBar().pushMessage(
            "DGM1 NRW", f"{n_new} tiles downloaded, {n_old} already there; {vrt.name} added", Qgis.Success, 8)


def _download(task, rows, folder, vrt):
    """Runs in the worker thread: no map, no layers, no message bar here, only files and task.setProgress()."""
    files, n_new = [], 0
    for i, r in enumerate(rows):
        status = core.download_tile(r["file"], r["size_bytes"], folder, is_canceled=task.isCanceled)
        n_new += status == "downloaded"
        log(f"{r['file']}: {status}")
        files.append(folder / r["file"])
        task.setProgress(100 * (i + 1) / len(rows))
    return core.build_vrt(files, vrt), n_new, len(rows) - n_new
