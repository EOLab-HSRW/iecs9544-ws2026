"""DGM1 tiles of NRW: file list, tile index, download, VRT. No GUI in this module.

The same logic as the console script geo0443_DGM1_Tiles_QGIS_Console.py, but every function
gets the data folder as an argument and reports through a `log` function instead of the
message bar, so that it can run in a background task (QgsTask) and be tested without QGIS GUI.

Files (same layout as geo0442 and both console scripts):
  <data>/original/dgm1_tiff/index.xml, index.json, dgm1_32_*.tif, *.vrt
  <data>/derived/dgm1_tile_index.gpkg   layers dgm1_tiles, index_info
"""
import json
import re
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from pathlib import Path

from osgeo import gdal, ogr, osr

DGM1_URL = "https://www.opengeodata.nrw.de/produkte/geobasis/hm/dgm1_tiff/dgm1_tiff/"
HEADERS = {"User-Agent": "opengeo QGIS plugin dgm1_nrw_tiles (geo0443)"}
EPSG = 25832
TILE = 1000
NAME = re.compile(r"^dgm1_32_(?P<e_km>\d{3})_(?P<n_km>\d{4})_1_nw_(?P<year>\d{4})\.tif$")
LICENCE = "Geobasis NRW, dl-de/zero-2-0"


class Canceled(Exception):
    """Raised inside a download when the user cancels the task."""


def paths(root):
    root = Path(root)
    original, derived = root / "original" / "dgm1_tiff", root / "derived"
    for folder in (original, derived):
        folder.mkdir(parents=True, exist_ok=True)
    return {"original": original, "xml": original / "index.xml", "json": original / "index.json",
            "gpkg": derived / "dgm1_tile_index.gpkg"}


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def fetch_listing(root, force=False, max_age_hours=24, log=print):
    """(xml bytes, info, changed) of the file list: local copy, or a conditional GET (304 = unchanged)."""
    p = paths(root)
    info = json.loads(p["json"].read_text(encoding="utf-8")) if p["json"].exists() else {}
    have = p["xml"].exists()
    if have and not force:
        checked = datetime.strptime(info.get("checked", info.get("downloaded", "2000-01-01 00:00")), "%Y-%m-%d %H:%M")
        if datetime.now() - checked < timedelta(hours=max_age_hours):
            return p["xml"].read_bytes(), info, False
    headers = dict(HEADERS)
    if have and info.get("etag"):
        headers["If-None-Match"] = info["etag"]
    if have and info.get("last_modified"):
        headers["If-Modified-Since"] = info["last_modified"]
    try:
        with urllib.request.urlopen(urllib.request.Request(DGM1_URL, headers=headers), timeout=60) as r:
            body = r.read()
            info = {"url": DGM1_URL, "downloaded": _now(), "checked": _now(),
                    "last_modified": r.headers.get("Last-Modified"), "etag": r.headers.get("ETag")}
    except urllib.error.HTTPError as e:
        if e.code != 304:
            raise
        info["checked"] = _now()
        p["json"].write_text(json.dumps(info, indent=1), encoding="utf-8")
        return p["xml"].read_bytes(), info, False
    except (urllib.error.URLError, TimeoutError) as e:
        if have:
            log(f"server not reachable ({e}); using the local file list of {info.get('downloaded')}")
            return p["xml"].read_bytes(), info, False
        raise
    p["xml"].write_bytes(body)
    p["json"].write_text(json.dumps(info, indent=1), encoding="utf-8")
    log(f"file list downloaded: {len(body) / 1e6:.1f} MB, Last-Modified {info['last_modified']}")
    return body, info, True


def parse_listing(xml_bytes):
    """One dict per tile: key, file, year, e_km, n_km, size_bytes, timestamp."""
    rows, bad = [], []
    for f in ET.fromstring(xml_bytes).iter("file"):
        m = NAME.match(f.get("name"))
        if m is None:
            bad.append(f.get("name"))
            continue
        e_km, n_km, year = (int(v) for v in m.group("e_km", "n_km", "year"))
        rows.append({"key": f"dgm1_32_{e_km}_{n_km}_1_nw", "file": f.get("name"), "year": year, "e_km": e_km,
                     "n_km": n_km, "size_bytes": int(f.get("size")), "timestamp": f.get("timestamp")})
    if bad:
        raise ValueError(f"{len(bad)} names do not fit the DGM1 pattern, e.g. {bad[:3]}: has the server changed?")
    if len({r["key"] for r in rows}) != len(rows):
        raise ValueError("a tile appears twice in the file list")
    return rows


def index_info(gpkg):
    if not Path(gpkg).exists():
        return {}
    ds = ogr.Open(str(gpkg))
    lyr = ds.GetLayerByName("index_info") if ds else None
    feat = lyr.GetNextFeature() if lyr else None
    return {} if feat is None else {k: feat.GetField(k) for k in feat.keys()}


def index_is_current(gpkg, rows, info):
    old = index_info(gpkg)
    return bool(old) and old.get("tiles") == len(rows) and \
        (old.get("last_modified") or "") == (info.get("last_modified") or "")


def build_index(rows, info, gpkg, log=print):
    """GeoPackage with dgm1_tiles (one 1 km square per tile) and index_info (where and when from)."""
    for suffix in ("", "-wal", "-shm"):
        Path(str(gpkg) + suffix).unlink(missing_ok=True)
    ds = ogr.GetDriverByName("GPKG").CreateDataSource(str(gpkg))
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(EPSG)
    lyr = ds.CreateLayer("dgm1_tiles", srs, ogr.wkbPolygon, options=["SPATIAL_INDEX=YES"])
    for name, kind in (("key", ogr.OFTString), ("file", ogr.OFTString), ("year", ogr.OFTInteger),
                       ("e_km", ogr.OFTInteger), ("n_km", ogr.OFTInteger), ("size_mb", ogr.OFTReal),
                       ("size_bytes", ogr.OFTInteger64), ("timestamp", ogr.OFTDateTime)):
        lyr.CreateField(ogr.FieldDefn(name, kind))
    defn = lyr.GetLayerDefn()
    lyr.StartTransaction()
    for r in rows:
        x0, y0 = r["e_km"] * TILE, r["n_km"] * TILE
        feat = ogr.Feature(defn)
        for k in ("key", "file", "year", "e_km", "n_km", "size_bytes", "timestamp"):
            feat.SetField(k, r[k])
        feat.SetField("size_mb", round(r["size_bytes"] / 1e6, 2))
        feat.SetGeometry(ogr.CreateGeometryFromWkt(
            f"POLYGON(({x0} {y0},{x0 + TILE} {y0},{x0 + TILE} {y0 + TILE},{x0} {y0 + TILE},{x0} {y0}))"))
        lyr.CreateFeature(feat)
    lyr.CommitTransaction()
    tab = ds.CreateLayer("index_info", None, ogr.wkbNone)
    fields = {"source": DGM1_URL, "last_modified": info.get("last_modified") or "", "etag": info.get("etag") or "",
              "downloaded": info.get("downloaded") or "", "tiles": len(rows), "licence": LICENCE}
    for k, v in fields.items():
        tab.CreateField(ogr.FieldDefn(k, ogr.OFTInteger if isinstance(v, int) else ogr.OFTString))
    feat = ogr.Feature(tab.GetLayerDefn())
    for k, v in fields.items():
        feat.SetField(k, v)
    tab.CreateFeature(feat)
    ds = None
    log(f"tile index written: {gpkg} ({len(rows)} tiles)")


def download_tile(file, size_bytes, folder, is_canceled=lambda: False):
    """One tile into `folder`: skip if present with the right size; .part file, size check, cancel between chunks."""
    target = Path(folder) / file
    if target.exists() and target.stat().st_size == size_bytes:
        return "exists"
    part = target.with_name(target.name + ".part")
    with urllib.request.urlopen(urllib.request.Request(DGM1_URL + file, headers=HEADERS), timeout=60) as r, \
            open(part, "wb") as f:
        while chunk := r.read(1 << 16):
            if is_canceled():
                f.close()
                part.unlink(missing_ok=True)
                raise Canceled(file)
            f.write(chunk)
    if part.stat().st_size != size_bytes:
        raise IOError(f"{file}: {part.stat().st_size} bytes, the index says {size_bytes}")
    part.replace(target)
    return "downloaded"


def build_vrt(files, vrt):
    """Virtual raster next to the tiles (GDAL writes relative paths there)."""
    gdal.BuildVRT(str(vrt), [str(f) for f in files]).FlushCache()
    return Path(vrt)
