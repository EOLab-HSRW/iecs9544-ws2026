"""DGM1 NRW Tile Downloader: QGIS plugin (opengeo teaching example, geo0443).

QGIS imports this package and calls classFactory(iface) once; it must return the plugin object.
"""


def classFactory(iface):
    from .plugin import Dgm1TilesPlugin      # import here, not at the top: QGIS is fully started now
    return Dgm1TilesPlugin(iface)
